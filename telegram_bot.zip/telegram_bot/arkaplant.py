from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    filters,
    ConversationHandler,
    ContextTypes,
)

# مراحل گفتگو
ASK_NAME, ASK_PHONE, ASK_LOCATION = range(3)

# شروع مکالمه
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("سلام! 🌿\nبرای ثبت درخواست ویزیت، لطفاً اسمت رو بفرست.")
    return ASK_NAME

# گرفتن اسم
async def get_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['name'] = update.message.text
    await update.message.reply_text("شماره تماست چنده؟ 📞")
    return ASK_PHONE

# گرفتن شماره
async def get_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['phone'] = update.message.text
    await update.message.reply_text("کجا زندگی می‌کنی؟ (مثلاً تهران - ونک) 🌍")
    return ASK_LOCATION

# گرفتن موقعیت و ارسال به ادمین
async def get_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['location'] = update.message.text
    name = context.user_data['name']
    phone = context.user_data['phone']
    loc = context.user_data['location']

    # ارسال پیام به کاربر
    await update.message.reply_text(
        f"✅ اطلاعات ثبت شد!\n\n🪴 اسم: {name}\n📞 شماره: {phone}\n📍 موقعیت: {loc}\n\n"
        "به‌زودی باهات تماس می‌گیریم 🌿"
    )

    # ارسال پیام به ادمین
    admin_id = 601990813
    admin_message = f"📥 درخواست جدید:\n\n🪴 اسم: {name}\n📞 شماره: {phone}\n📍 موقعیت: {loc}"
    await context.bot.send_message(chat_id=admin_id, text=admin_message)

    return ConversationHandler.END

# لغو
async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("مکالمه لغو شد ❌")
    return ConversationHandler.END

# اجرای ربات
def main():
    app = ApplicationBuilder().token("8031627965:AAGOJLFHpJ5XCE_dCv-At_gTxz5VgdxeKjQ").build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            ASK_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_name)],
            ASK_PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_phone)],
            ASK_LOCATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_location)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    app.add_handler(conv_handler)
    app.run_polling()

if __name__ == '__main__':
    main()